class Resolvers::CreateStudent < GraphQL::Function
    
    argument :name, !types.String
    argument :lastname, !types.String
    argument :email, !types.String
    argument :code, !types.Int
    argument :telephone, !types.Int
  
    
    type Types::StudentType
  
    # the mutation method
    # _obj - is parent object, which in this case is nil
    # args - are the arguments passed
    # _ctx - is the GraphQL context (which would be discussed later)
    def call(_obj, args, _ctx)
      Student.create!(
        name: args[:name],
        lastname: args[:lastname],
        email: args[:email],
        code: args[:code],
        telephone: args[:telephone],
      )
    end
end