Types::StudentType = GraphQL::ObjectType.define do

    name 'Student'

    field :id, !types.ID
    field :name, !types.String
    field :lastname, !types.String
    field :email, !types.String
    field :code, !types.Int
    field :telephone, !types.Int

end