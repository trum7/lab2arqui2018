class AssignController < ApplicationController


    def assign

        @student = params[:student]
        @course = params[:course]
        @grade = params[:grade]
  
        result_student = checkStudent(@student)
        result_course = checkCourse(@course)
  
        puts result_student
        puts result_course

        if result_student.include? "name" and result_course.include? "name"
  
          options = {
            :body =>
           {
              :student_id => @student,
              :course_id => @course,
              :grade_value => @grade
            }.to_json,
  
            :headers => { 'Content-Type' => 'application/json' }
           }
  
           results = HTTParty.post("http://192.168.99.101:5000/grades", options )
  
        end
  
      end
  
      def checkStudent(id)
  
        results = HTTParty.get("http://192.168.99.101:3000/students/" + id.to_s )
        return results
      end
  
      def checkCourse(id)
  
        results = HTTParty.get("http://192.168.99.101:4040/courses/resources/course/" + id.to_s )
        return results
  
      end

      private
 
 
      # Only allow a trusted parameter "white list" through.
      def assign_params
        params.permit(:student, :course, :grade)
      end

end
