class Grade < ApplicationRecord
end
